# Caso de Uso: Hoteles y Hospitalidad

## Descripción General
Esta implementación está específicamente diseñada para hoteles, resorts, hostels y otros establecimientos de hospitalidad que buscan automatizar su presencia en redes sociales y mejorar la comunicación con huéspedes actuales y potenciales.

## Objetivos Específicos
- Promocionar experiencias y servicios del hotel
- Aumentar bookings directos desde redes sociales
- Proporcionar información turística actualizada
- Gestionar consultas de reservas de manera eficiente
- Construir una comunidad de huéspedes leales

## Configuración Específica para Hoteles

### ContentCreatorAgent - Configuración Hotelera

#### Temas de Contenido Prioritarios
```yaml
content_themes:
  weather_content:
    priority: high
    frequency: daily
    templates:
      - sunny_day_activities
      - rainy_day_indoor
      - perfect_weather_attractions

  local_attractions:
    priority: high
    frequency: weekly
    templates:
      - nearby_restaurants
      - tourist_attractions
      - cultural_events
      - shopping_areas

  hotel_amenities:
    priority: medium
    frequency: bi_weekly
    templates:
      - pool_showcase
      - spa_services
      - restaurant_highlights
      - room_features

  seasonal_promotions:
    priority: high
    frequency: monthly
    templates:
      - summer_packages
      - holiday_specials
      - early_booking_discounts
      - last_minute_deals
```

#### Prompts Específicos para Contenido Hotelero
```python
HOTEL_CONTENT_PROMPTS = {
    "weather_based": '''
    Basándote en los siguientes datos meteorológicos: {weather_data}
    Y eventos locales: {local_events}

    Genera contenido para Instagram que:
    1. Conecte el clima con actividades disponibles
    2. Promocione servicios del hotel relevantes al clima
    3. Incluya información útil para huéspedes
    4. Use un tono acogedor y profesional
    5. Incluya call-to-action para reservas

    Hotel: {hotel_name}
    Ubicación: {location}
    Servicios destacados: {amenities}
    ''',

    "local_attraction": '''
    Crea contenido promocional sobre atracciones locales cerca del hotel:
    Atracción: {attraction_name}
    Distancia: {distance}
    Tipo: {attraction_type}

    El contenido debe:
    1. Destacar la proximidad del hotel a la atracción
    2. Proporcionar información práctica (horarios, precios)
    3. Sugerir cómo el hotel complementa la experiencia
    4. Incluir hashtags relevantes
    5. Motivar reservas con packages especiales
    ''',

    "amenity_showcase": '''
    Crea contenido que destaque las amenidades del hotel:
    Amenidad a destacar: {amenity}
    Temporada: {season}
    Target: {target_audience}

    El contenido debe:
    1. Mostrar los beneficios únicos de la amenidad
    2. Conectar con las necesidades del huésped
    3. Crear deseo y aspiración
    4. Incluir testimonios o experiencias
    5. Promocionar packages relacionados
    '''
}
```

### EngagementAgent - Configuración Hotelera

#### Horarios Optimizados para Hoteles
```python
HOTEL_POSTING_SCHEDULE = {
    "instagram_feed": {
        "monday": ["09:00", "19:00"],      # Lunes: Motivación + Atardecer
        "tuesday": ["10:00", "17:00"],     # Martes: Mid-morning + Pre-dinner
        "wednesday": ["09:30", "20:00"],   # Miércoles: Clima + Evening
        "thursday": ["11:00", "18:00"],    # Jueves: Actividades + Sunset
        "friday": ["08:30", "19:30"],      # Viernes: Weekend prep + Social
        "saturday": ["10:30", "16:00"],    # Sábado: Late morning + Afternoon
        "sunday": ["09:00", "18:30"]       # Domingo: Relax + Planning
    },

    "instagram_stories": {
        "frequency": "every_4_hours",
        "peak_times": ["09:00", "13:00", "17:00", "21:00"]
    },

    "whatsapp_status": {
        "frequency": "twice_daily",
        "times": ["10:00", "17:00"]
    }
}
```

#### Respuestas Automatizadas Específicas
```python
HOTEL_AUTO_RESPONSES = {
    "booking_inquiry": {
        "triggers": ["disponibilidad", "reserva", "precio", "tarifa", "habitación"],
        "response": '''
        ¡Gracias por tu interés en {hotel_name}! 

        Para consultas sobre disponibilidad y reservas, nuestro equipo especializado te ayudará:

        📞 WhatsApp: {whatsapp_number}
        📧 Email: {booking_email}
        🌐 Reserva online: {booking_url}

        Horario de atención: {business_hours}

        ¡Esperamos recibirte pronto! ✨
        ''',
        "escalate_to": "booking_team"
    },

    "amenities_question": {
        "triggers": ["piscina", "spa", "wifi", "desayuno", "parking", "gym"],
        "response": '''
        ¡Excelente pregunta! En {hotel_name} contamos con:

        {amenities_list}

        Para más detalles sobre nuestros servicios:
        📱 {contact_phone}
        📧 {info_email}

        ¿Te gustaría que te enviemos más información específica?
        ''',
        "escalate_to": "guest_services"
    },

    "local_info": {
        "triggers": ["restaurantes", "atracciones", "turismo", "transporte", "playa"],
        "response": '''
        ¡Nos encanta ayudarte a descubrir {city_name}! 

        Nuestro equipo de concierge tiene las mejores recomendaciones locales:

        📍 Atracciones cercanas
        🍽️ Restaurantes recomendados  
        🚶‍♂️ Rutas a pie
        🚗 Opciones de transporte

        Contáctanos: {concierge_contact}

        ¡Haz que tu estadía sea inolvidable! 🌟
        '''
    }
}
```

### ReceptionAgent - Configuración Hotelera

#### Clasificación Específica de Mensajes
```python
HOTEL_MESSAGE_CLASSIFICATION = {
    "booking_request": {
        "confidence_threshold": 0.85,
        "keywords": [
            "reserva", "disponibilidad", "habitación", "precio", 
            "tarifa", "booking", "check-in", "check-out", "huésped"
        ],
        "action": "escalate_to_reservations",
        "priority": "high"
    },

    "guest_service": {
        "confidence_threshold": 0.80,
        "keywords": [
            "servicio", "problema", "queja", "solicitud", "amenidades",
            "limpieza", "mantenimiento", "room service", "concierge"
        ],
        "action": "escalate_to_guest_services",
        "priority": "medium"
    },

    "local_information": {
        "confidence_threshold": 0.75,
        "keywords": [
            "turismo", "restaurante", "atracción", "playa", "museo",
            "shopping", "transporte", "taxi", "actividades"
        ],
        "action": "provide_info_and_escalate",
        "priority": "low"
    },

    "compliment": {
        "confidence_threshold": 0.90,
        "keywords": [
            "gracias", "excelente", "hermoso", "perfecto", "increíble",
            "maravilloso", "recomiendo", "felicitaciones"
        ],
        "action": "auto_respond_positive",
        "priority": "low"
    }
}
```

## Implementación Paso a Paso para Hoteles

### Fase 1: Configuración Inicial (Semana 1)
1. **Configurar APIs básicas**
   - Instagram Business Account
   - WhatsApp Business API
   - OpenWeather API para la ubicación del hotel
   - Eventbrite/local events API

2. **Personalizar configuración del hotel**
   ```bash
   # Variables específicas del hotel
   COMPANY_NAME="Hotel Paradise Beach"
   COMPANY_LOCATION="Cancún, México"
   BUSINESS_TYPE="hotel"
   WEATHER_CITY="Cancun"
   TARGET_AUDIENCE="travelers,tourists,couples,families"
   ```

3. **Configurar plantillas de contenido**
   - Templates para días soleados
   - Templates para días lluviosos
   - Templates para promociones
   - Templates para amenidades

### Fase 2: Personalización de Agentes (Semana 2)
1. **ContentCreatorAgent personalizado**
   - Prompts específicos del hotel
   - Estilos visuales de la marca
   - Hashtags del hotel y destino

2. **EngagementAgent optimizado**
   - Horarios de publicación óptimos
   - Respuestas automáticas en español/inglés
   - Configuración de engagement rules

3. **ReceptionAgent especializado**
   - Clasificación de consultas hoteleras
   - Escalation rules específicas
   - Respuestas predefinidas

### Fase 3: Testing y Refinamiento (Semana 3)
1. **Pruebas de contenido**
   - Generar contenido de muestra
   - Validar calidad y relevancia
   - Ajustar prompts según necesidad

2. **Pruebas de interacción**
   - Simular consultas de huéspedes
   - Verificar clasificación correcta
   - Ajustar thresholds de confianza

3. **Pruebas de escalation**
   - Verificar routing a equipos correctos
   - Confirmar respuestas automáticas
   - Ajustar timing de respuestas

### Fase 4: Despliegue Gradual (Semana 4)
1. **Despliegue en horarios de baja actividad**
2. **Monitoreo constante de interacciones**
3. **Ajustes en tiempo real**
4. **Escalamiento progresivo**

## Métricas Específicas para Hoteles

### KPIs de Contenido
- **Engagement Rate por tipo de contenido**
  - Contenido climático vs. amenidades
  - Posts informativos vs. promocionales
  - Contenido en español vs. inglés

- **Reach y Impressions**
  - Alcance por demografía
  - Impresiones por horario
  - Performance por día de la semana

### KPIs de Conversión
- **Leads generados desde redes sociales**
  - Consultas de reserva por canal
  - Tiempo de respuesta promedio
  - Tasa de conversión de consulta a reserva

- **Engagement Quality**
  - Comentarios positivos vs. negativos
  - Preguntas vs. elogios
  - Menciones orgánicas del hotel

### KPIs Operativos
- **Eficiencia del sistema**
  - Consultas resueltas automáticamente
  - Consultas escaladas correctamente
  - Tiempo de respuesta por tipo de consulta

## Personalización Avanzada

### Integración con PMS (Property Management System)
```python
# Ejemplo de integración con sistema de reservas
class HotelPMSIntegration:
    def __init__(self, pms_api_key):
        self.pms_client = PMSClient(pms_api_key)

    def check_availability(self, checkin_date, checkout_date, room_type="any"):
        availability = self.pms_client.get_availability(
            start_date=checkin_date,
            end_date=checkout_date,
            room_category=room_type
        )
        return availability

    def get_current_promotions(self):
        promotions = self.pms_client.get_active_promotions()
        return [promo for promo in promotions if promo.is_active()]

    def create_booking_link(self, room_type, dates):
        return self.pms_client.generate_booking_url(room_type, dates)
```

### Personalización por Temporada
```yaml
seasonal_configuration:
  high_season:
    months: [12, 1, 2, 3, 4]
    content_focus: ["luxury_experience", "premium_amenities", "exclusive_services"]
    posting_frequency: "3x_daily"
    promotion_intensity: "low"

  low_season:
    months: [5, 6, 9, 10, 11]
    content_focus: ["value_offers", "local_experiences", "relaxation"]
    posting_frequency: "2x_daily"
    promotion_intensity: "high"

  hurricane_season:
    months: [7, 8]
    content_focus: ["indoor_activities", "spa_wellness", "culinary_experiences"]
    posting_frequency: "daily"
    backup_content: true
```

Esta configuración específica para hoteles permite maximizar el impacto del sistema multi-agente en el sector de hospitalidad, adaptándose a las necesidades únicas de comunicación, marketing y servicio al cliente de los establecimientos hoteleros.
