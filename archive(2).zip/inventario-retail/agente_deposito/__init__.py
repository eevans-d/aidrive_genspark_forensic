"""
AgenteDepósito - Gestión ACID de stock e inventario
"""
__version__ = "1.0.0"
