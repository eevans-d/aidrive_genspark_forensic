"""
Sistema de Gestión de Depósito - Agente de Depósito
Versión: 1.0.0
Autor: Sistema Automatizado
"""

__version__ = "1.0.0"
__author__ = "Sistema Automatizado"
__description__ = "Sistema completo de gestión de depósito con control ACID"
