"""
OCR Postprocessor Avanzado
=========================

Postprocessor para limpiar y mejorar resultados de OCR, corregir errores
comunes, aplicar correcciones específicas para facturas argentinas y
generar confidence scores finales.

Autor: Sistema Inventario Retail Argentino
Fecha: 2025-08-22
"""

import re
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
import logging
import difflib
from collections import Counter

@dataclass
class PostprocessResult:
    """Resultado del postprocesamiento con metadatos"""
    original_text: str
    cleaned_text: str
    corrections_made: List[str]
    confidence_score: float
    structured_data: Dict
    processing_stats: Dict

class OCRPostprocessor:
    """Postprocessor avanzado para resultados OCR de facturas argentinas"""

    def __init__(self):
        self.logger = logging.getLogger(__name__)

        # Diccionario de correcciones comunes OCR
        self.ocr_corrections = {
            # Números confundidos con letras
            'O': '0',  # O mayúscula por cero
            'l': '1',  # l minúscula por uno
            'I': '1',  # I mayúscula por uno
            'S': '5',  # S por cinco
            'B': '8',  # B por ocho
            '6': 'G',  # Al revés para texto
            '5': 'S',  # Al revés para texto
            '1': 'I',  # Al revés para texto
            '0': 'O',  # Al revés para texto

            # Caracteres especiales mal leídos
            '|': 'I',
            '!': 'I',
            '¡': 'I',
            ')': 'D',
            '(': 'C',
            '€': 'C',
            '@': 'a',
            '&': '8',
        }

        # Patrones de corrección contextual
        self.context_patterns = {
            # CUIT patterns
            r'CUIT[:\s]*([OI][\d-\s]+)': self._correct_cuit_ocr,
            r'C\.U\.I\.T[:\s]*([OI][\d-\s]+)': self._correct_cuit_ocr,

            # Fecha patterns
            r'(\d{1,2}[/\-][OI]\d{1}[/\-]\d{2,4})': self._correct_fecha_ocr,
            r'(FECHA[:\s]*\d{1,2}[/\-][OI]\d{1}[/\-]\d{2,4})': self._correct_fecha_ocr,

            # Montos patterns
            r'(\$\s*[OI]\d*[.,]\d+)': self._correct_monto_ocr,
            r'(TOTAL[:\s]*\$?\s*[OI]\d*[.,]\d+)': self._correct_monto_ocr,

            # Números de factura
            r'(N°\s*[OI]\d{3}[-\s]*[OI]\d+)': self._correct_numero_factura_ocr,

            # Palabras comunes mal leídas
            r'FAG[TU]URA': 'FACTURA',
            r'RAZ[OI]N': 'RAZON',
            r'S[OI]CIAL': 'SOCIAL',
            r'T[OI]TAL': 'TOTAL',
            r'SUBT[OI]TAL': 'SUBTOTAL',
            r'D[OI]MICILIO': 'DOMICILIO',
        }

        # Diccionario de palabras válidas para corrección de spelling
        self.valid_words = {
            'factura', 'nota', 'credito', 'debito', 'remito',
            'razon', 'social', 'cuit', 'fecha', 'total', 'subtotal',
            'domicilio', 'direccion', 'telefono', 'condicion',
            'responsable', 'inscripto', 'monotributo', 'exento',
            'consumidor', 'final', 'productos', 'cantidad',
            'precio', 'unitario', 'importe', 'descuento'
        }

        # Estadísticas para mejora continua
        self.stats = {
            'texts_processed': 0,
            'corrections_made': 0,
            'avg_confidence_improvement': 0.0,
            'common_errors': Counter()
        }

    def postprocess_ocr_result(self, ocr_text: str, original_confidence: float = 0.8) -> PostprocessResult:
        """
        Postprocesar resultado de OCR completo

        Args:
            ocr_text: Texto extraído por OCR
            original_confidence: Confidence score original del OCR

        Returns:
            PostprocessResult con texto limpio y metadatos
        """
        corrections_made = []
        processing_stats = {
            'original_length': len(ocr_text),
            'original_confidence': original_confidence
        }

        try:
            # 1. Limpieza básica
            cleaned_text = self._basic_cleaning(ocr_text)
            if cleaned_text != ocr_text:
                corrections_made.append("limpieza_basica")

            # 2. Correcciones por contexto
            context_corrected, context_corrections = self._apply_context_corrections(cleaned_text)
            corrections_made.extend(context_corrections)

            # 3. Corrección de caracteres individuales
            char_corrected, char_corrections = self._apply_character_corrections(context_corrected)
            corrections_made.extend(char_corrections)

            # 4. Corrección de palabras (spell checking básico)
            word_corrected, word_corrections = self._apply_word_corrections(char_corrected)
            corrections_made.extend(word_corrections)

            # 5. Normalización final
            final_text = self._final_normalization(word_corrected)
            if final_text != word_corrected:
                corrections_made.append("normalizacion_final")

            # 6. Extraer datos estructurados
            structured_data = self._extract_structured_data(final_text)

            # 7. Calcular confidence score final
            final_confidence = self._calculate_final_confidence(
                original_confidence, len(corrections_made), structured_data
            )

            # Actualizar estadísticas
            processing_stats.update({
                'final_length': len(final_text),
                'corrections_count': len(corrections_made),
                'final_confidence': final_confidence,
                'confidence_improvement': final_confidence - original_confidence,
                'structured_fields_found': len(structured_data)
            })

            self._update_stats(corrections_made, final_confidence - original_confidence)

            return PostprocessResult(
                original_text=ocr_text,
                cleaned_text=final_text,
                corrections_made=corrections_made,
                confidence_score=final_confidence,
                structured_data=structured_data,
                processing_stats=processing_stats
            )

        except Exception as e:
            self.logger.error(f"Error en postprocesamiento: {e}")
            return PostprocessResult(
                original_text=ocr_text,
                cleaned_text=ocr_text,  # Fallback al original
                corrections_made=[f"error: {str(e)}"],
                confidence_score=original_confidence * 0.8,  # Penalizar por error
                structured_data={},
                processing_stats=processing_stats
            )

    def _basic_cleaning(self, text: str) -> str:
        """Limpieza básica del texto"""
        # Remover caracteres de control y espacios extra
        cleaned = re.sub(r'[ --]', '', text)

        # Normalizar espacios
        cleaned = re.sub(r'\s+', ' ', cleaned)

        # Remover espacios al inicio y final
        cleaned = cleaned.strip()

        # Remover líneas vacías múltiples
        cleaned = re.sub(r'
\s*
', '
', cleaned)

        return cleaned

    def _apply_context_corrections(self, text: str) -> Tuple[str, List[str]]:
        """Aplicar correcciones basadas en contexto"""
        corrected_text = text
        corrections = []

        for pattern, correction in self.context_patterns.items():
            if callable(correction):
                # Es una función de corrección
                new_text, made_correction = correction(corrected_text, pattern)
                if made_correction:
                    corrected_text = new_text
                    corrections.append(f"contexto_{correction.__name__}")
            else:
                # Es una sustitución simple
                new_text = re.sub(pattern, correction, corrected_text, flags=re.IGNORECASE)
                if new_text != corrected_text:
                    corrected_text = new_text
                    corrections.append(f"contexto_{pattern[:10]}")

        return corrected_text, corrections

    def _correct_cuit_ocr(self, text: str, pattern: str) -> Tuple[str, bool]:
        """Corregir errores OCR específicos en CUIT"""
        def replace_cuit(match):
            cuit_part = match.group(1)
            # Reemplazar O e I por 0 y 1 en números CUIT
            corrected = cuit_part.replace('O', '0').replace('I', '1')
            return match.group(0).replace(cuit_part, corrected)

        corrected = re.sub(pattern, replace_cuit, text, flags=re.IGNORECASE)
        return corrected, corrected != text

    def _correct_fecha_ocr(self, text: str, pattern: str) -> Tuple[str, bool]:
        """Corregir errores OCR específicos en fechas"""
        def replace_fecha(match):
            fecha_part = match.group(1)
            # Corregir O e I en posiciones de mes
            corrected = fecha_part.replace('O', '0').replace('I', '1')
            return match.group(0).replace(fecha_part, corrected)

        corrected = re.sub(pattern, replace_fecha, text, flags=re.IGNORECASE)
        return corrected, corrected != text

    def _correct_monto_ocr(self, text: str, pattern: str) -> Tuple[str, bool]:
        """Corregir errores OCR específicos en montos"""
        def replace_monto(match):
            monto_part = match.group(1)
            # Corregir O e I al inicio de números
            corrected = re.sub(r'^([^0-9]*)[OI]', r'\g<1>1', monto_part)
            corrected = re.sub(r'^([^0-9]*)O', r'\g<1>0', corrected)
            return match.group(0).replace(monto_part, corrected)

        corrected = re.sub(pattern, replace_monto, text, flags=re.IGNORECASE)
        return corrected, corrected != text

    def _correct_numero_factura_ocr(self, text: str, pattern: str) -> Tuple[str, bool]:
        """Corregir errores OCR en números de factura"""
        def replace_numero(match):
            numero_part = match.group(1)
            # Corregir O e I en números de factura
            corrected = numero_part.replace('O', '0').replace('I', '1')
            return match.group(0).replace(numero_part, corrected)

        corrected = re.sub(pattern, replace_numero, text, flags=re.IGNORECASE)
        return corrected, corrected != text

    def _apply_character_corrections(self, text: str) -> Tuple[str, List[str]]:
        """Aplicar correcciones de caracteres individuales"""
        corrected_text = text
        corrections = []

        # Correcciones en contexto numérico
        numeric_corrections = 0

        # Corregir O por 0 en contextos numéricos
        numeric_pattern = r'\b\d*O\d*\b'
        if re.search(numeric_pattern, corrected_text):
            corrected_text = re.sub(r'(\d+)O(\d*)', r'\g<1>0\g<2>', corrected_text)
            numeric_corrections += 1

        # Corregir I por 1 en contextos numéricos  
        if re.search(r'\b\d*I\d*\b', corrected_text):
            corrected_text = re.sub(r'(\d+)I(\d*)', r'\g<1>1\g<2>', corrected_text)
            numeric_corrections += 1

        if numeric_corrections > 0:
            corrections.append(f"caracteres_numericos_{numeric_corrections}")

        # Correcciones en contexto de texto
        text_corrections = 0
        for wrong, correct in self.ocr_corrections.items():
            # Solo aplicar en contexto apropiado
            if wrong in ['0', '1', '5', '6'] and re.search(r'[A-Za-z]', corrected_text):
                # Corregir números por letras solo en palabras
                pattern = rf'(?<=[A-Za-z]){re.escape(wrong)}(?=[A-Za-z])'
                if re.search(pattern, corrected_text):
                    corrected_text = re.sub(pattern, correct, corrected_text)
                    text_corrections += 1

        if text_corrections > 0:
            corrections.append(f"caracteres_texto_{text_corrections}")

        return corrected_text, corrections

    def _apply_word_corrections(self, text: str) -> Tuple[str, List[str]]:
        """Aplicar correcciones de palabras (spell checking básico)"""
        corrected_text = text
        corrections = []

        # Separar texto en palabras
        words = re.findall(r'\b[A-Za-zÁÉÍÓÚÑáéíóúñ]+\b', text)

        corrected_words = 0
        for word in words:
            word_lower = word.lower()

            # Buscar palabra similar en diccionario
            if word_lower not in self.valid_words:
                # Usar difflib para encontrar palabra más similar
                similar_words = difflib.get_close_matches(
                    word_lower, self.valid_words, n=1, cutoff=0.6
                )

                if similar_words:
                    similar_word = similar_words[0]
                    # Preservar capitalización original
                    if word.isupper():
                        replacement = similar_word.upper()
                    elif word.istitle():
                        replacement = similar_word.title()
                    else:
                        replacement = similar_word

                    # Reemplazar en el texto
                    corrected_text = re.sub(rf'\b{re.escape(word)}\b', replacement, corrected_text)
                    corrected_words += 1

        if corrected_words > 0:
            corrections.append(f"palabras_corregidas_{corrected_words}")

        return corrected_text, corrections

    def _final_normalization(self, text: str) -> str:
        """Normalización final del texto"""
        # Normalizar espacios alrededor de signos de puntuación
        normalized = re.sub(r'\s*([,:])\s*', r'\1 ', text)

        # Normalizar espacios alrededor de números
        normalized = re.sub(r'([A-Za-z])\s*([0-9])', r'\1 \2', normalized)
        normalized = re.sub(r'([0-9])\s*([A-Za-z])', r'\1 \2', normalized)

        # Normalizar formato de montos
        normalized = re.sub(r'\$\s*', '$', normalized)

        # Normalizar múltiples espacios
        normalized = re.sub(r'\s+', ' ', normalized)

        return normalized.strip()

    def _extract_structured_data(self, text: str) -> Dict:
        """Extraer datos estructurados del texto limpio"""
        structured = {}

        # Patrones para extraer campos específicos
        patterns = {
            'cuit': r'CUIT[:\s]*(\d{2}[-\s]*\d{8}[-\s]*\d{1})',
            'numero_factura': r'N°[:\s]*(\d{4}[-\s]*\d{8})',
            'fecha': r'FECHA[:\s]*(\d{1,2}[/\-]\d{1,2}[/\-]\d{2,4})',
            'total': r'TOTAL[:\s]*\$?\s*(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)',
            'razon_social': r'RAZON\s+SOCIAL[:\s]*([A-Z\s\.]+)',
        }

        for field, pattern in patterns.items():
            match = re.search(pattern, text.upper())
            if match:
                structured[field] = match.group(1).strip()

        return structured

    def _calculate_final_confidence(self, original_confidence: float, 
                                  corrections_count: int, structured_data: Dict) -> float:
        """Calcular confidence score final"""
        # Base score es la confianza original
        base_score = original_confidence

        # Ajustar por correcciones hechas
        if corrections_count > 0:
            # Muchas correcciones pueden indicar OCR malo, pero también mejora
            correction_factor = min(0.1, corrections_count * 0.02)  # Máximo 10% boost
            base_score += correction_factor

        # Boost por datos estructurados encontrados
        structure_boost = len(structured_data) * 0.05  # 5% por campo encontrado
        base_score += structure_boost

        # Penalizar si muy pocos campos estructurados
        if len(structured_data) < 2:
            base_score *= 0.9

        # Mantener en rango [0, 1]
        return max(0.0, min(1.0, base_score))

    def _update_stats(self, corrections: List[str], confidence_improvement: float):
        """Actualizar estadísticas del postprocessor"""
        self.stats['texts_processed'] += 1
        self.stats['corrections_made'] += len(corrections)

        # Actualizar promedio de mejora de confianza
        n = self.stats['texts_processed']
        prev_avg = self.stats['avg_confidence_improvement']
        self.stats['avg_confidence_improvement'] = ((prev_avg * (n-1)) + confidence_improvement) / n

        # Contar errores comunes
        for correction in corrections:
            self.stats['common_errors'][correction] += 1

    def get_stats(self) -> Dict:
        """Obtener estadísticas del postprocessor"""
        return {
            **self.stats,
            'most_common_errors': dict(self.stats['common_errors'].most_common(5))
        }

    def batch_postprocess(self, ocr_results: List[Tuple[str, float]]) -> List[PostprocessResult]:
        """Procesar múltiples resultados OCR en batch"""
        results = []

        for ocr_text, confidence in ocr_results:
            try:
                result = self.postprocess_ocr_result(ocr_text, confidence)
                results.append(result)
            except Exception as e:
                self.logger.error(f"Error en batch postprocessing: {e}")
                # Agregar resultado de error
                results.append(PostprocessResult(
                    original_text=ocr_text,
                    cleaned_text=ocr_text,
                    corrections_made=[f"batch_error: {str(e)}"],
                    confidence_score=confidence * 0.5,
                    structured_data={},
                    processing_stats={}
                ))

        return results

    def export_corrections_dictionary(self) -> Dict:
        """Exportar diccionario de correcciones para análisis"""
        return {
            'character_corrections': self.ocr_corrections,
            'context_patterns': {k: str(v) for k, v in self.context_patterns.items()},
            'valid_words': list(self.valid_words),
            'usage_stats': self.get_stats()
        }

# Ejemplo de uso
if __name__ == "__main__":
    postprocessor = OCRPostprocessor()

    # Test con texto OCR típico con errores
    texto_ocr_ejemplo = """
    FAGTURA B
    CUIT: 2O-I2345678-9
    N° OOO1-OOOOO123
    FEGHA: I5/O8/2O25
    T0TAL: $I.234,56
    RAZ0N S0CIAL: EMPRESA EJEMPLO S.R.L.
    """

    resultado = postprocessor.postprocess_ocr_result(texto_ocr_ejemplo, 0.75)

    print("=== OCR POSTPROCESSOR TEST ===")
    print(f"Texto original: {resultado.original_text[:100]}...")
    print(f"Texto corregido: {resultado.cleaned_text[:100]}...")
    print(f"Correcciones: {resultado.corrections_made}")
    print(f"Confidence: {resultado.processing_stats['original_confidence']:.3f} → {resultado.confidence_score:.3f}")
    print(f"Datos extraídos: {resultado.structured_data}")
