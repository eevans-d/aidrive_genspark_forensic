# Guía de Instalación del Sistema Multi-Agente

## Requisitos del Sistema

### Requisitos Mínimos
- **CPU**: 2 cores, 2.4 GHz
- **RAM**: 4 GB
- **Almacenamiento**: 10 GB disponibles
- **Sistema Operativo**: Ubuntu 20.04+, CentOS 8+, macOS 10.15+, Windows 10+

### Requisitos Recomendados
- **CPU**: 4+ cores, 3.0+ GHz
- **RAM**: 8+ GB
- **Almacenamiento**: 50+ GB SSD
- **Red**: Conexión estable a internet
- **Base de Datos**: PostgreSQL 13+, Redis 6+

## Pre-requisitos de Software

### 1. Instalación de Docker y Docker Compose
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install docker.io docker-compose
sudo usermod -aG docker $USER

# CentOS/RHEL
sudo yum install docker docker-compose
sudo systemctl start docker
sudo systemctl enable docker

# macOS (usando Homebrew)
brew install docker docker-compose

# Windows
# Descargar Docker Desktop desde https://www.docker.com/products/docker-desktop
```

### 2. Instalación de Node.js y Python
```bash
# Node.js (usando NodeSource)
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Python 3.9+
sudo apt install python3 python3-pip python3-venv

# Verificar instalaciones
node --version
python3 --version
docker --version
```

## Instalación Rápida con Docker

### 1. Clonar o Descargar la Configuración
```bash
# Crear directorio del proyecto
mkdir sistema-multiagente-social
cd sistema-multiagente-social

# Descargar configuración de ejemplo
curl -O https://raw.githubusercontent.com/ejemplo/multiagente/main/docker-compose.yml
curl -O https://raw.githubusercontent.com/ejemplo/multiagente/main/.env.example
```

### 2. Configurar Variables de Entorno
```bash
# Copiar archivo de ejemplo
cp .env.example .env

# Editar variables de entorno
nano .env
```

### 3. Despliegue con Docker Compose
```bash
# Iniciar todos los servicios
docker-compose up -d

# Verificar estado de los servicios
docker-compose ps

# Ver logs
docker-compose logs -f
```

## Instalación Manual Detallada

### 1. Configuración de Base de Datos PostgreSQL
```bash
# Instalar PostgreSQL
sudo apt install postgresql postgresql-contrib

# Crear usuario y base de datos
sudo -u postgres createuser --interactive --pwprompt multiagent_user
sudo -u postgres createdb -O multiagent_user multiagent_db

# Configurar acceso
sudo nano /etc/postgresql/13/main/pg_hba.conf
# Añadir: local   multiagent_db   multiagent_user   md5

sudo systemctl restart postgresql
```

### 2. Configuración de Redis
```bash
# Instalar Redis
sudo apt install redis-server

# Configurar Redis
sudo nano /etc/redis/redis.conf
# Descomentar: requirepass your_redis_password

sudo systemctl restart redis-server
sudo systemctl enable redis-server
```

### 3. Configuración de ChromaDB (Base de Datos Vectorial)
```bash
# Crear entorno virtual Python
python3 -m venv venv_chroma
source venv_chroma/bin/activate

# Instalar ChromaDB
pip install chromadb

# Crear script de inicio
cat > start_chroma.py << 'EOF'
import chromadb
from chromadb.config import Settings

if __name__ == "__main__":
    client = chromadb.HttpClient(
        host="0.0.0.0",
        port=8000,
        settings=Settings(
            chroma_db_impl="duckdb+parquet",
            persist_directory="./chroma_db"
        )
    )
    print("ChromaDB started on http://0.0.0.0:8000")
EOF

# Ejecutar ChromaDB
python start_chroma.py
```

### 4. Configuración de N8N
```bash
# Instalar N8N globalmente
npm install n8n -g

# O usar Docker
docker run -it --rm \
  --name n8n \
  -p 5678:5678 \
  -e N8N_BASIC_AUTH_ACTIVE=true \
  -e N8N_BASIC_AUTH_USER=admin \
  -e N8N_BASIC_AUTH_PASSWORD=admin123 \
  -v ~/.n8n:/home/node/.n8n \
  n8nio/n8n

# Acceder a N8N: http://localhost:5678
```

## Configuración de APIs Externas

### 1. Instagram Graph API
```bash
# 1. Crear Facebook App en developers.facebook.com
# 2. Configurar Instagram Basic Display
# 3. Obtener tokens de acceso

# Variables de entorno necesarias:
export INSTAGRAM_ACCESS_TOKEN="your_instagram_token"
export INSTAGRAM_ACCOUNT_ID="your_account_id"
export FACEBOOK_APP_ID="your_app_id"
export FACEBOOK_APP_SECRET="your_app_secret"
```

### 2. WhatsApp Business API
```bash
# 1. Configurar WhatsApp Business en Meta Developer
# 2. Obtener Phone Number ID y Access Token
# 3. Configurar Webhook

# Variables de entorno necesarias:
export WHATSAPP_ACCESS_TOKEN="your_whatsapp_token"
export WHATSAPP_PHONE_NUMBER_ID="your_phone_id"
export WHATSAPP_WEBHOOK_VERIFY_TOKEN="your_verify_token"
```

### 3. OpenAI API
```bash
# 1. Crear cuenta en platform.openai.com
# 2. Generar API Key
# 3. Configurar límites de uso

export OPENAI_API_KEY="sk-your-openai-key"
export OPENAI_MODEL="gpt-4"
```

### 4. OpenWeatherMap API
```bash
# 1. Registrarse en openweathermap.org
# 2. Obtener API Key gratuita

export WEATHER_API_KEY="your_weather_api_key"
export WEATHER_CITY="Buenos Aires"
```

## Configuración del Sistema Multi-Agente

### 1. Estructura de Archivos
```
sistema-multiagente/
├── agents/
│   ├── content_creator_agent.py
│   ├── engagement_agent.py
│   ├── reception_agent.py
│   └── analytics_agent.py
├── config/
│   ├── agents.yaml
│   ├── workflows.json
│   └── templates.yaml
├── services/
│   ├── instagram_api.py
│   ├── whatsapp_api.py
│   ├── openai_service.py
│   └── weather_service.py
├── database/
│   ├── models.py
│   ├── migrations/
│   └── seeds/
├── docker-compose.yml
├── requirements.txt
└── .env
```

### 2. Instalación de Dependencias Python
```bash
# Crear entorno virtual
python3 -m venv venv_multiagent
source venv_multiagent/bin/activate

# Instalar dependencias
pip install -r requirements.txt
```

#### requirements.txt
```
fastapi==0.104.1
uvicorn==0.24.0
sqlalchemy==2.0.23
psycopg2-binary==2.9.9
redis==5.0.1
chromadb==0.4.18
openai==1.3.5
requests==2.31.0
python-multipart==0.0.6
python-dotenv==1.0.0
pydantic==2.5.0
celery==5.3.4
schedule==1.2.0
pillow==10.1.0
aiohttp==3.9.1
```

### 3. Configuración de Agentes
```yaml
# config/agents.yaml
agents:
  content_creator:
    enabled: true
    model: "gpt-4"
    temperature: 0.8
    max_tokens: 1500
    schedule: "0 9,15,19 * * *"

  engagement:
    enabled: true
    schedule: "*/15 * * * *"
    auto_response: true
    sentiment_threshold: 0.7

  reception:
    enabled: true
    model: "gpt-4"
    classification_threshold: 0.8
    auto_escalate: true

  analytics:
    enabled: true
    schedule: "0 6 * * *"
    retention_days: 365
```

## Verificación de la Instalación

### 1. Test de Conectividad a APIs
```bash
# Script de verificación
python3 -c "
import requests
import os
from dotenv import load_dotenv

load_dotenv()

# Test OpenAI
headers = {'Authorization': f'Bearer {os.getenv("OPENAI_API_KEY")}'}
response = requests.get('https://api.openai.com/v1/models', headers=headers)
print(f'OpenAI API: {"✅" if response.status_code == 200 else "❌"}')

# Test Weather API
weather_key = os.getenv('WEATHER_API_KEY')
response = requests.get(f'https://api.openweathermap.org/data/2.5/weather?q=London&appid={weather_key}')
print(f'Weather API: {"✅" if response.status_code == 200 else "❌"}')

# Test Database
try:
    import psycopg2
    conn = psycopg2.connect(os.getenv('DATABASE_URL'))
    print('Database: ✅')
    conn.close()
except:
    print('Database: ❌')
"
```

### 2. Test de Servicios Docker
```bash
# Verificar todos los contenedores
docker-compose ps

# Test de salud de servicios
curl http://localhost:3000/health
curl http://localhost:8000/api/v1/heartbeat  # ChromaDB
curl http://localhost:5678  # N8N
```

### 3. Test de Agentes
```bash
# Ejecutar test básico de agentes
python3 -c "
import sys
sys.path.append('./agents')

try:
    from content_creator_agent import ContentCreatorAgent
    agent = ContentCreatorAgent()
    print('ContentCreatorAgent: ✅')
except Exception as e:
    print(f'ContentCreatorAgent: ❌ - {e}')

try:
    from engagement_agent import EngagementAgent
    agent = EngagementAgent()
    print('EngagementAgent: ✅')
except Exception as e:
    print(f'EngagementAgent: ❌ - {e}')
"
```

## Solución de Problemas Comunes

### 1. Error de Conexión a Base de Datos
```bash
# Verificar estado de PostgreSQL
sudo systemctl status postgresql

# Verificar conectividad
pg_isready -h localhost -p 5432

# Verificar credenciales
psql -h localhost -U multiagent_user -d multiagent_db
```

### 2. Error de APIs Externas
```bash
# Verificar variables de entorno
env | grep -E "(OPENAI|INSTAGRAM|WHATSAPP|WEATHER)"

# Test manual de API
curl -H "Authorization: Bearer $OPENAI_API_KEY" https://api.openai.com/v1/models
```

### 3. Problemas con Docker
```bash
# Reiniciar servicios Docker
docker-compose down
docker-compose up -d

# Limpiar volúmenes si es necesario
docker-compose down -v
```

### 4. Problemas de Permisos
```bash
# Ajustar permisos de archivos
chmod +x scripts/*.sh
chown -R $USER:$USER .

# Ajustar permisos de Docker
sudo usermod -aG docker $USER
newgrp docker
```

## Configuración de Producción

### 1. Configuración de Proxy Reverso (Nginx)
```nginx
# /etc/nginx/sites-available/multiagent
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }

    location /n8n {
        proxy_pass http://localhost:5678;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

### 2. Configuración de SSL con Let's Encrypt
```bash
# Instalar Certbot
sudo apt install certbot python3-certbot-nginx

# Obtener certificado SSL
sudo certbot --nginx -d your-domain.com

# Auto-renovación
sudo crontab -e
# Añadir: 0 12 * * * /usr/bin/certbot renew --quiet
```

### 3. Configuración de Monitoreo
```bash
# Instalar herramientas de monitoreo
docker run -d --name prometheus \
  -p 9090:9090 \
  prom/prometheus

docker run -d --name grafana \
  -p 3001:3000 \
  grafana/grafana
```

¡Instalación completada! El sistema multi-agente debería estar funcionando correctamente. Consulta los logs regularmente y ajusta la configuración según las necesidades específicas de tu negocio.
