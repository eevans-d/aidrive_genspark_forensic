# Variables de Entorno del Sistema Multi-Agente

```bash
# Variables de Entorno del Sistema Multi-Agente

# =============================================================================
# CONFIGURACIÓN GENERAL
# =============================================================================
ENVIRONMENT=production
LOG_LEVEL=info
DEBUG=false
SERVICE_NAME=social-media-multiagent
SERVICE_VERSION=1.0.0

# =============================================================================
# APIS DE INTELIGENCIA ARTIFICIAL
# =============================================================================
# OpenAI
OPENAI_API_KEY=sk-your-openai-api-key-here
OPENAI_MODEL=gpt-4
OPENAI_MAX_TOKENS=2000
OPENAI_TEMPERATURE=0.7

# Claude (Anthropic)
CLAUDE_API_KEY=your-claude-api-key-here
CLAUDE_MODEL=claude-3-sonnet

# Gemini (Google)
GOOGLE_API_KEY=your-google-api-key-here
GEMINI_MODEL=gemini-pro

# DALL-E para generación de imágenes
DALLE_API_KEY=your-dalle-api-key-here
DALLE_MODEL=dall-e-3
DALLE_SIZE=1024x1024
DALLE_QUALITY=standard

# =============================================================================
# APIS DE REDES SOCIALES
# =============================================================================
# Instagram Graph API
INSTAGRAM_ACCESS_TOKEN=your-instagram-access-token-here
INSTAGRAM_ACCOUNT_ID=your-instagram-account-id
INSTAGRAM_APP_ID=your-facebook-app-id
INSTAGRAM_APP_SECRET=your-facebook-app-secret

# WhatsApp Business API
WHATSAPP_ACCESS_TOKEN=your-whatsapp-access-token-here
WHATSAPP_PHONE_NUMBER_ID=your-phone-number-id
WHATSAPP_WEBHOOK_VERIFY_TOKEN=your-webhook-verify-token
WHATSAPP_BUSINESS_ACCOUNT_ID=your-business-account-id

# =============================================================================
# APIS DE DATOS EXTERNOS
# =============================================================================
# OpenWeatherMap
WEATHER_API_KEY=your-openweather-api-key-here
WEATHER_CITY=Buenos Aires
WEATHER_COUNTRY_CODE=AR
WEATHER_UNITS=metric

# Eventbrite (eventos locales)
EVENTBRITE_API_KEY=your-eventbrite-api-key-here
EVENTBRITE_LOCATION=Buenos Aires

# News API (noticias locales)
NEWS_API_KEY=your-news-api-key-here
NEWS_COUNTRY=ar
NEWS_LANGUAGE=es

# =============================================================================
# BASES DE DATOS
# =============================================================================
# PostgreSQL (Base de datos principal)
DATABASE_URL=postgresql://user:password@localhost:5432/multiagent_db
DB_HOST=localhost
DB_PORT=5432
DB_NAME=multiagent_db
DB_USER=multiagent_user
DB_PASSWORD=secure_password
DB_SSL_MODE=require

# ChromaDB (Base de datos vectorial)
VECTOR_DB_URL=http://localhost:8000
VECTOR_DB_COLLECTION=social_content
VECTOR_DB_PERSIST_DIR=./chroma_db

# Redis (Cache y sesiones)
REDIS_URL=redis://localhost:6379/0
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=redis_password
REDIS_DB=0

# =============================================================================
# CONFIGURACIÓN DE AGENTES
# =============================================================================
# ContentCreatorAgent
CONTENT_CREATOR_ENABLED=true
CONTENT_CREATOR_SCHEDULE=0 9,15,19 * * *
CONTENT_CREATOR_MODEL=gpt-4
CONTENT_CREATOR_TEMPERATURE=0.8
CONTENT_CREATOR_MAX_TOKENS=1500

# EngagementAgent
ENGAGEMENT_ENABLED=true
ENGAGEMENT_SCHEDULE=*/15 * * * *
ENGAGEMENT_AUTO_RESPONSE=true
ENGAGEMENT_SENTIMENT_THRESHOLD=0.7

# ReceptionAgent
RECEPTION_ENABLED=true
RECEPTION_MODEL=gpt-4
RECEPTION_CLASSIFICATION_THRESHOLD=0.8
RECEPTION_AUTO_ESCALATE=true
RECEPTION_RESPONSE_TIMEOUT=300

# AnalyticsAgent
ANALYTICS_ENABLED=true
ANALYTICS_SCHEDULE=0 6 * * *
ANALYTICS_RETENTION_DAYS=365
ANALYTICS_REPORTING_EMAIL=admin@company.com

# =============================================================================
# CONFIGURACIÓN ESPECÍFICA DEL NEGOCIO
# =============================================================================
# Información de la empresa
COMPANY_NAME=Mi Empresa
COMPANY_DESCRIPTION=Descripción de mi empresa
COMPANY_LOCATION=Buenos Aires, Argentina
COMPANY_WEBSITE=https://www.miempresa.com
COMPANY_EMAIL=contacto@miempresa.com
COMPANY_PHONE=+54 11 1234-5678

# Tipo de industria (hotel, restaurant, retail, services)
BUSINESS_TYPE=hotel
BUSINESS_CATEGORY=hospitality
TARGET_AUDIENCE=travelers,tourists,business

# Horarios de operación
BUSINESS_HOURS_START=09:00
BUSINESS_HOURS_END=22:00
BUSINESS_TIMEZONE=America/Argentina/Buenos_Aires

# =============================================================================
# CONFIGURACIÓN DE CONTENIDO
# =============================================================================
# Configuración de hashtags
DEFAULT_HASHTAGS=#miempresa,#buenosaires,#argentina
BRAND_HASHTAGS=#marcapropia,#experienciaunica
INDUSTRY_HASHTAGS=#turismo,#viajes,#hotel

# Configuración de tono y estilo
CONTENT_TONE=professional
CONTENT_STYLE=informative
CONTENT_LANGUAGE=es

# =============================================================================
# SEGURIDAD Y AUTENTICACIÓN
# =============================================================================
# JWT para autenticación interna
JWT_SECRET=your-super-secret-jwt-key-here
JWT_EXPIRATION=24h

# Webhooks security
WEBHOOK_SECRET=your-webhook-secret-here

# Rate limiting
RATE_LIMIT_REQUESTS=100
RATE_LIMIT_WINDOW=15m

# =============================================================================
# MONITOREO Y LOGGING
# =============================================================================
# Sentry para error tracking
SENTRY_DSN=https://your-sentry-dsn-here

# Datadog para métricas
DATADOG_API_KEY=your-datadog-api-key-here

# Logging
LOG_FORMAT=json
LOG_OUTPUT=stdout
LOG_FILE_PATH=/var/log/multiagent.log

# =============================================================================
# CONFIGURACIÓN DE DESPLIEGUE
# =============================================================================
# Servidor
PORT=3000
HOST=0.0.0.0
NODE_ENV=production

# Health checks
HEALTH_CHECK_ENABLED=true
HEALTH_CHECK_PATH=/health

# Métricas
METRICS_ENABLED=true
METRICS_PATH=/metrics
METRICS_PORT=9090

# =============================================================================
# CONFIGURACIÓN DE NOTIFICACIONES
# =============================================================================
# Email (para alertas y reportes)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=noreply@miempresa.com
SMTP_PASSWORD=email_password
SMTP_FROM=Sistema Multi-Agente <noreply@miempresa.com>

# Slack (para notificaciones del equipo)
SLACK_WEBHOOK_URL=https://hooks.slack.com/services/your/slack/webhook
SLACK_CHANNEL=#social-media-alerts

# =============================================================================
# CONFIGURACIÓN AVANZADA
# =============================================================================
# Configuración de reintentos
MAX_RETRIES=3
RETRY_DELAY=5000
BACKOFF_FACTOR=2

# Timeouts
API_TIMEOUT=30000
DATABASE_TIMEOUT=10000
CACHE_TIMEOUT=5000

# Configuración de caché
CACHE_TTL=3600
CACHE_MAX_SIZE=1000

# Configuración de archivos
UPLOAD_MAX_SIZE=10485760
ALLOWED_FILE_TYPES=jpg,jpeg,png,gif,mp4,mov
STORAGE_PATH=/var/uploads

# =============================================================================
# FEATURES FLAGS
# =============================================================================
FEATURE_AUTO_POSTING=true
FEATURE_AUTO_RESPONSE=true
FEATURE_SENTIMENT_ANALYSIS=true
FEATURE_IMAGE_GENERATION=true
FEATURE_VIDEO_GENERATION=false
FEATURE_ANALYTICS_DASHBOARD=true
FEATURE_A_B_TESTING=true
FEATURE_MULTILINGUAL=false

# =============================================================================
# CONFIGURACIÓN DE TESTING
# =============================================================================
TEST_MODE=false
TEST_INSTAGRAM_ACCOUNT=test_account
TEST_WHATSAPP_NUMBER=+1234567890
MOCK_EXTERNAL_APIS=false

# =============================================================================
# CONFIGURACIÓN ESPECÍFICA POR AMBIENTE
# =============================================================================
# Desarrollo
DEV_DATABASE_URL=postgresql://dev_user:dev_pass@localhost:5432/multiagent_dev
DEV_REDIS_URL=redis://localhost:6379/1

# Staging
STAGING_DATABASE_URL=postgresql://staging_user:staging_pass@staging-db:5432/multiagent_staging
STAGING_REDIS_URL=redis://staging-redis:6379/0

# Producción (las variables principales ya están definidas arriba)
PRODUCTION_MONITORING_ENABLED=true
PRODUCTION_DEBUG_LOGS=false
PRODUCTION_PERFORMANCE_TRACKING=true

```