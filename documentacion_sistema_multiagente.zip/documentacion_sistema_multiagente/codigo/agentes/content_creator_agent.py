"""
Ejemplo de implementación del ContentCreatorAgent
Sistema Multi-Agente para Automatización de Redes Sociales
"""

import os
import asyncio
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import asdict

import openai
import requests
from pydantic import BaseModel
from sqlalchemy import create_engine, Column, Integer, String, DateTime, Text, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# Configuración de logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Modelos de datos
Base = declarative_base()

class ContentPost(Base):
    """Modelo para almacenar posts generados"""
    __tablename__ = "content_posts"

    id = Column(Integer, primary_key=True)
    content_type = Column(String(50))  # 'instagram_feed', 'instagram_story', 'whatsapp_status'
    title = Column(String(200))
    caption = Column(Text)
    image_prompt = Column(Text)
    image_url = Column(String(500))
    hashtags = Column(Text)
    scheduled_time = Column(DateTime)
    posted = Column(Boolean, default=False)
    engagement_metrics = Column(Text)  # JSON string
    created_at = Column(DateTime, default=datetime.utcnow)

class ContentIdea(BaseModel):
    """Estructura para ideas de contenido"""
    theme: str
    visual_style: str
    message_tone: str
    call_to_action: str
    hashtags: List[str]
    target_audience: str
    weather_context: Optional[Dict] = None
    local_events: Optional[List[Dict]] = None

class ContentCreatorAgent:
    """
    Agente especializado en creación de contenido para redes sociales
    """

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.openai_client = openai.OpenAI(api_key=config['openai_api_key'])
        self.setup_database()

        # Configuración específica del agente
        self.model = config.get('model', 'gpt-4')
        self.temperature = config.get('temperature', 0.8)
        self.max_tokens = config.get('max_tokens', 1500)
        self.business_type = config.get('business_type', 'general')
        self.company_name = config.get('company_name', 'Mi Empresa')
        self.location = config.get('location', 'Buenos Aires')

    def setup_database(self):
        """Configurar conexión a base de datos"""
        database_url = self.config['database_url']
        self.engine = create_engine(database_url)
        Base.metadata.create_all(self.engine)
        Session = sessionmaker(bind=self.engine)
        self.db_session = Session()

    async def gather_context_data(self) -> Dict[str, Any]:
        """Recopilar datos contextuales para la creación de contenido"""
        context = {}

        try:
            # Datos meteorológicos
            weather_data = await self.get_weather_data()
            context['weather'] = weather_data

            # Eventos locales
            local_events = await self.get_local_events()
            context['events'] = local_events

            # Fecha y hora actual
            now = datetime.now()
            context['datetime'] = {
                'date': now.strftime('%Y-%m-%d'),
                'time': now.strftime('%H:%M'),
                'day_of_week': now.strftime('%A'),
                'month': now.strftime('%B'),
                'season': self.get_season(now.month)
            }

            # Datos específicos del negocio
            context['business'] = {
                'name': self.company_name,
                'type': self.business_type,
                'location': self.location
            }

        except Exception as e:
            logger.error(f"Error gathering context data: {e}")
            context['error'] = str(e)

        return context

    async def get_weather_data(self) -> Dict[str, Any]:
        """Obtener datos meteorológicos"""
        api_key = self.config.get('weather_api_key')
        city = self.config.get('weather_city', self.location)

        if not api_key:
            return {}

        url = f"https://api.openweathermap.org/data/2.5/weather"
        params = {
            'q': city,
            'appid': api_key,
            'units': 'metric',
            'lang': 'es'
        }

        try:
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            data = response.json()

            return {
                'temperature': data['main']['temp'],
                'feels_like': data['main']['feels_like'],
                'description': data['weather'][0]['description'],
                'humidity': data['main']['humidity'],
                'wind_speed': data['wind']['speed'],
                'visibility': data.get('visibility', 0) / 1000,  # Convert to km
                'icon': data['weather'][0]['icon']
            }
        except Exception as e:
            logger.error(f"Error fetching weather data: {e}")
            return {}

    async def get_local_events(self) -> List[Dict[str, Any]]:
        """Obtener eventos locales (simulado - implementar con API real)"""
        # Aquí se integraría con APIs como Eventbrite, Facebook Events, etc.
        return [
            {
                'name': 'Festival de Música Local',
                'date': '2025-02-01',  
                'location': 'Plaza Central',
                'type': 'cultural'
            },
            {
                'name': 'Mercado Gastronómico',
                'date': '2025-02-03',
                'location': 'Parque de la Ciudad',
                'type': 'food'
            }
        ]

    def get_season(self, month: int) -> str:
        """Determinar estación del año (hemisferio sur)"""
        if month in [12, 1, 2]:
            return 'verano'
        elif month in [3, 4, 5]:
            return 'otoño'
        elif month in [6, 7, 8]:
            return 'invierno'
        else:
            return 'primavera'

    async def generate_content_idea(self, context: Dict[str, Any]) -> ContentIdea:
        """Generar idea de contenido basada en contexto"""

        # Prompt personalizado según tipo de negocio
        prompt_templates = {
            'hotel': self.get_hotel_content_prompt(context),
            'restaurant': self.get_restaurant_content_prompt(context),
            'retail': self.get_retail_content_prompt(context),
            'services': self.get_services_content_prompt(context)
        }

        prompt = prompt_templates.get(self.business_type, 
                                    self.get_general_content_prompt(context))

        try:
            response = self.openai_client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "Eres un especialista en marketing de contenido para redes sociales. "
                                 "Generas ideas creativas y contextuales para diferentes tipos de negocio."
                    },
                    {
                        "role": "user", 
                        "content": prompt
                    }
                ],
                temperature=self.temperature,
                max_tokens=800
            )

            content_text = response.choices[0].message.content

            # Parsear la respuesta para extraer elementos estructurados
            idea = self.parse_content_idea(content_text, context)

            return idea

        except Exception as e:
            logger.error(f"Error generating content idea: {e}")
            # Fallback a idea genérica
            return ContentIdea(
                theme="promocional",
                visual_style="profesional",
                message_tone="amigable",
                call_to_action="Visítanos",
                hashtags=[f"#{self.company_name.lower().replace(' ', '')}"],
                target_audience="general"
            )

    def get_hotel_content_prompt(self, context: Dict[str, Any]) -> str:
        """Prompt específico para hoteles"""
        weather = context.get('weather', {})
        events = context.get('events', [])
        datetime_info = context.get('datetime', {})

        return f"""
        Genera una idea de contenido para Instagram de un hotel llamado {self.company_name} 
        ubicado en {self.location}.

        Contexto actual:
        - Fecha: {datetime_info.get('date')} ({datetime_info.get('day_of_week')})
        - Clima: {weather.get('description', 'información no disponible')}
        - Temperatura: {weather.get('temperature', 'N/A')}°C
        - Eventos locales: {', '.join([e['name'] for e in events[:2]])}

        La idea debe:
        1. Conectar el clima/fecha con actividades del hotel o turísticas
        2. Ser atractiva para huéspedes potenciales
        3. Incluir call-to-action para reservas
        4. Sugerir hashtags relevantes
        5. Tener un tono acogedor y profesional

        Responde en formato JSON con:
        - theme: tema principal
        - visual_style: estilo visual sugerido
        - message_tone: tono del mensaje
        - call_to_action: llamada a la acción
        - hashtags: array de hashtags
        - target_audience: audiencia objetivo
        - content_text: texto del post
        - image_description: descripción para generar imagen
        """

    def get_restaurant_content_prompt(self, context: Dict[str, Any]) -> str:
        """Prompt específico para restaurantes"""
        datetime_info = context.get('datetime', {})
        weather = context.get('weather', {})

        return f"""
        Genera contenido para un restaurante llamado {self.company_name} en {self.location}.

        Contexto:
        - Día: {datetime_info.get('day_of_week')}
        - Hora: {datetime_info.get('time')}
        - Clima: {weather.get('description', 'normal')}

        Considera:
        - Platos especiales según día/clima
        - Horario del día (desayuno/almuerzo/cena)
        - Ambiente y experiencia gastronómica

        Formato JSON igual al anterior.
        """

    def get_retail_content_prompt(self, context: Dict[str, Any]) -> str:
        """Prompt específico para retail"""
        return f"""
        Genera contenido para una tienda {self.company_name} en {self.location}.

        Enfócate en:
        - Productos destacados
        - Ofertas o promociones
        - Tendencias actuales
        - Experiencia de compra

        Formato JSON igual al anterior.
        """

    def get_services_content_prompt(self, context: Dict[str, Any]) -> str:
        """Prompt específico para servicios"""
        return f"""
        Genera contenido para {self.company_name}, empresa de servicios en {self.location}.

        Destaca:
        - Beneficios del servicio
        - Casos de éxito
        - Valor agregado
        - Llamada a consulta

        Formato JSON igual al anterior.
        """

    def get_general_content_prompt(self, context: Dict[str, Any]) -> str:
        """Prompt genérico para cualquier tipo de negocio"""
        return f"""
        Genera contenido para {self.company_name} en {self.location}.

        Crea contenido atractivo y relevante para redes sociales.

        Formato JSON igual al anterior.
        """

    def parse_content_idea(self, content_text: str, context: Dict[str, Any]) -> ContentIdea:
        """Parsear respuesta de IA y crear ContentIdea estructurada"""
        try:
            # Intentar parsear como JSON primero
            if content_text.strip().startswith('{'):
                data = json.loads(content_text)
                return ContentIdea(
                    theme=data.get('theme', 'general'),
                    visual_style=data.get('visual_style', 'professional'),
                    message_tone=data.get('message_tone', 'friendly'),
                    call_to_action=data.get('call_to_action', 'Contáctanos'),
                    hashtags=data.get('hashtags', []),
                    target_audience=data.get('target_audience', 'general'),
                    weather_context=context.get('weather'),
                    local_events=context.get('events')
                )
        except json.JSONDecodeError:
            pass

        # Fallback: extraer información del texto libre
        return ContentIdea(
            theme="promocional",
            visual_style="atractivo",
            message_tone="profesional",
            call_to_action="Visítanos",
            hashtags=[f"#{self.company_name.lower().replace(' ', '')}"],
            target_audience="general",
            weather_context=context.get('weather'),
            local_events=context.get('events')
        )

    async def generate_visual_content(self, idea: ContentIdea) -> str:
        """Generar imagen usando DALL-E"""
        image_prompt = f"""
        Crear una imagen para {idea.theme} de {self.company_name}.
        Estilo: {idea.visual_style}
        Tono: {idea.message_tone}

        La imagen debe ser:
        - Profesional y atractiva para redes sociales
        - Formato cuadrado (1024x1024)
        - Con colores vibrantes pero elegantes
        - Sin texto superpuesto
        """

        if idea.weather_context:
            weather_desc = idea.weather_context.get('description', '')
            image_prompt += f"\nContexto climático: {weather_desc}"

        try:
            response = self.openai_client.images.generate(
                model="dall-e-3",
                prompt=image_prompt,
                size="1024x1024",
                quality="standard",
                n=1
            )

            return response.data[0].url

        except Exception as e:
            logger.error(f"Error generating image: {e}")
            return ""

    async def create_complete_post(self, content_type: str = "instagram_feed") -> Dict[str, Any]:
        """Crear post completo con texto e imagen"""

        # 1. Recopilar contexto
        context = await self.gather_context_data()

        # 2. Generar idea de contenido
        idea = await self.generate_content_idea(context)

        # 3. Generar imagen
        image_url = await self.generate_visual_content(idea)

        # 4. Crear texto del post
        post_text = await self.generate_post_text(idea, context)

        # 5. Crear post en base de datos
        post = ContentPost(
            content_type=content_type,
            title=idea.theme,
            caption=post_text,
            image_prompt=str(asdict(idea)),
            image_url=image_url,
            hashtags=' '.join(idea.hashtags),
            scheduled_time=datetime.now() + timedelta(minutes=5)
        )

        self.db_session.add(post)
        self.db_session.commit()

        return {
            'id': post.id,
            'content_type': content_type,
            'caption': post_text,
            'image_url': image_url,
            'hashtags': idea.hashtags,
            'scheduled_time': post.scheduled_time.isoformat(),
            'idea': asdict(idea)
        }

    async def generate_post_text(self, idea: ContentIdea, context: Dict[str, Any]) -> str:
        """Generar texto específico para el post"""

        prompt = f"""
        Escribe el texto para una publicación de Instagram para {self.company_name}.

        Detalles de la idea:
        - Tema: {idea.theme}
        - Tono: {idea.message_tone}
        - Call to action: {idea.call_to_action}
        - Audiencia: {idea.target_audience}

        Contexto:
        - Clima: {context.get('weather', {}).get('description', 'N/A')}
        - Fecha: {context.get('datetime', {}).get('date', 'N/A')}

        Requisitos:
        - Máximo 200 caracteres
        - Incluir emojis relevantes
        - Tono {idea.message_tone}
        - Terminar con call-to-action
        - NO incluir hashtags (se añaden por separado)
        """

        try:
            response = self.openai_client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "Eres un copywriter experto en redes sociales."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7,
                max_tokens=150
            )

            return response.choices[0].message.content.strip()

        except Exception as e:
            logger.error(f"Error generating post text: {e}")
            return f"¡Descubre lo mejor de {self.company_name}! {idea.call_to_action} ✨"

# Ejemplo de uso
async def main():
    """Ejemplo de uso del ContentCreatorAgent"""

    config = {
        'openai_api_key': os.getenv('OPENAI_API_KEY'),
        'weather_api_key': os.getenv('WEATHER_API_KEY'),
        'database_url': os.getenv('DATABASE_URL', 'sqlite:///multiagent.db'),
        'model': 'gpt-4',
        'temperature': 0.8,
        'business_type': 'hotel',
        'company_name': 'Hotel Paradise Beach',
        'location': 'Cancún, México',
        'weather_city': 'Cancun'
    }

    agent = ContentCreatorAgent(config)

    try:
        # Crear post completo
        post = await agent.create_complete_post('instagram_feed')

        print("✅ Post creado exitosamente:")
        print(f"ID: {post['id']}")
        print(f"Texto: {post['caption']}")
        print(f"Imagen: {post['image_url']}")
        print(f"Hashtags: {', '.join(post['hashtags'])}")
        print(f"Programado para: {post['scheduled_time']}")

    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    asyncio.run(main())
